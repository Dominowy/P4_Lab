
CREATE VIEW dbo.viewCenJedFak
as
SELECT IDzamówienia, SUM(CenaJednostkowa*Ilość) as 'CenaŁączna'
FROM dbo.PozycjeZamówienia
GROUP BY IDzamówienia
go

